export default function DashboardScreen() {
  return (
    <></>
  )
}