import Header from "../../components/ui/Header";
import About from "./sections/About";
import Initial from "./sections/Initial";
import Services from "./sections/Services";

export default function HomeScren() {
  return (
    <main className="w-dvw h-max flex flex-col justify-center items-center">
      <Header />
      <Initial />
      <About />
      <Services />
    </main >
  )
}